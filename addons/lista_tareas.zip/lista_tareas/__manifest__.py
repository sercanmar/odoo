{
    'name': 'Lista de Tareas SGE',
    'version': '1.0',
    'summary': 'Gestion de tareas escolares',
    'author': 'sercanmar',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/views.xml',
    ],
    'application': True,
    'installable': True,
}
